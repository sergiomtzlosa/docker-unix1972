/* exit -- end runcom */

main() {
	seek(0, 0, 2);
}
